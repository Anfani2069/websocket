package com.websocket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServeurWebsocketApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServeurWebsocketApplication.class, args);
	}

}
