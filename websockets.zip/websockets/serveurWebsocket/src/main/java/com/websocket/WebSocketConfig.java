package com.websocket;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

	   @Override
	    public void registerStompEndpoints(StompEndpointRegistry registry) {
	        // Endpoint utilisé par les clients pour se connecter au serveur WebSocket
		   registry.addEndpoint("/ws"); 
		   registry.addEndpoint("/ws").withSockJS();
	    }

	    @Override
	    public void configureMessageBroker(MessageBrokerRegistry registry) {
	        // Configuration du message broker
	        registry.enableSimpleBroker("/topic"); // Préfixe des destinations des messages à envoyer aux clients
	        registry.setApplicationDestinationPrefixes("/app"); // Préfixe des destinations des messages venant des clients
	    }
}
