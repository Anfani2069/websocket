package clientWebSocket;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.socket.messaging.WebSocketStompClient;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.messaging.simp.stomp.StompSessionHandler;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;

@SpringBootApplication
public class ClientWebsocketApplication  {

    @Autowired
    private WebSocketStompClient stompClient;

    @Autowired
    private StompSessionHandler stompSessionHandler;

    public static void main(String[] args) {
        SpringApplication.run(ClientWebsocketApplication.class, args);
        

    }

 }
