package clientWebSocket;

import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompHeaders;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.messaging.simp.stomp.StompSessionHandlerAdapter;

public class MyStompSessionHandler extends StompSessionHandlerAdapter {

    @Override
    public void afterConnected(StompSession session, StompHeaders connectedHeaders) {
        session.subscribe("/topic/messages", this);
        //session.send("/app/chat", new ChatMessage("ALI", "TESTESTTESTTESTTEST"));
    }

    @Override
    public void handleFrame(StompHeaders headers, Object payload) {
        //System.out.println("Received message: " + payload.toString());
    }
}
