package clientWebSocket;

import jakarta.annotation.PreDestroy;
import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.messaging.converter.MappingJackson2MessageConverter;
import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompHeaders;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.messaging.simp.stomp.StompSessionHandler;
import org.springframework.stereotype.Controller;
import org.springframework.web.socket.client.WebSocketClient;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.messaging.WebSocketStompClient;

import com.fasterxml.jackson.databind.util.JSONPObject;

//import com.fasterxml.jackson.core.JsonParser;

import org.springframework.messaging.simp.SimpMessagingTemplate;
import java.lang.reflect.Type;

/**
 * Controller for the connection to the STOMP server.
 */
@Controller
@RequiredArgsConstructor
public class StompController implements StompSessionHandler {
    private StompSession stompSession;
    
    //private SimpMessagingTemplate messagingTemplate;
    
    @EventListener(value = ApplicationReadyEvent.class)
    public void connect() {
        WebSocketClient client = new StandardWebSocketClient();
        WebSocketStompClient stompClient = new WebSocketStompClient(client);
        // alternative: stompClient.setMessageConverter(new StringMessageConverter());
        stompClient.setMessageConverter(new MappingJackson2MessageConverter());
        try {
            stompSession = stompClient
                    .connect("ws://localhost:8080/ws", this)
                    .get();
        } catch (Exception e) {
            System.err.println("Connection failed." + e.getMessage()); // Do some failover and implement retry patterns.
        }
    }

    @Override
    public void afterConnected(StompSession session, StompHeaders connectedHeaders) {
        System.err.println("Connection to STOMP server established.\n" +
                "Session: " + session + "\n" +
                "Headers: " + connectedHeaders + "\n");

        subscribe("messages");
    }

    /**
     * Subscribes to the feed of the topic.
     *
     * @param topicId The id of the topic to subscribe for.
     */
    public void subscribe(String topicId) {
    	System.err.println("Subscribing to topic:  " + "/topic/"+topicId);
        stompSession.subscribe("/topic/" + topicId, this);
        stompSession.send("/app/chat", new ChatMessage("ALI", "TESTESTTESTTESTTEST",""));
        //messagingTemplate.convertAndSend("/topic/destination", "Message from client");
    }

    @Override
    public void handleFrame(StompHeaders headers, Object payload) {
    	//ChatMessage p= new ChatMessage(null,null,null);
    	ChatMessage p = (ChatMessage) payload;
    	System.out.println("Received message:" + p.getText());
        //System.err.println("Received message:" + p.getText());
        //String cadena = new String((byte[]) payload);
        
        //JSONParser parser = new JSONParser();
        //JSONObject json = (JSONObject) parser.parse(cadena);
        //JsonParser parser = new JsonParser();
        //JSONPObject obj = parser.parse(cadena).getAsJsonObject();
        System.out.println(payload);
    }

    @Override
    public void handleException(StompSession session, StompCommand command, StompHeaders headers, byte[] payload, Throwable exception) {
    	throw new RuntimeException("Failure in WebSocket handling", exception);
    }

    @Override
    public void handleTransportError(StompSession session, Throwable exception) {
        System.err.println("Retrieved a transport error: {}" + exception.getMessage());
        if (!session.isConnected()) {
            connect();
        }
    }

    @Override
    public Type getPayloadType(StompHeaders headers) {
        return ChatMessage.class;
    }

    /**
     * Unsubscribe and close connection before destroying this instance (e.g. on application shutdown).
     */
    @PreDestroy
    void onShutDown() {
        if (stompSession != null) {
            stompSession.disconnect();
        }
    }
}